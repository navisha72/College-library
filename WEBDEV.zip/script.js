const loginForm = document.getElementById('login-form');

loginForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  // Check if the username and password are valid (replace this with your own validation code)
  if (username === 'Cheetah' && password === '12345') {
    window.location.href = 'homepage.html';
  } else {
    window.location.href = 'tryagain.html';
  }
});
